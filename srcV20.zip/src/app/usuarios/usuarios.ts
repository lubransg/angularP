export class Usuarios {
    public ID_USUARIO: number;
}